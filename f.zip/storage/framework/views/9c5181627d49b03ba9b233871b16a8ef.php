<footer class="bg-gray-900 text-white p-4 mt-8">
    <div class="container mx-auto text-center">
        <p>&copy; <?php echo e(date('Y')); ?> Blue Star Memory. All rights reserved.</p>
        <div class="space-x-4 mt-2">
            <a  class="hover:text-gray-300">About</a>
            <a  class="hover:text-gray-300">Pricing</a>
            <a class="hover:text-gray-300">Contact</a>
        </div>
    </div>
</footer><?php /**PATH D:\Projects Frontend\blue-star-final\resources\views/components/footer.blade.php ENDPATH**/ ?>