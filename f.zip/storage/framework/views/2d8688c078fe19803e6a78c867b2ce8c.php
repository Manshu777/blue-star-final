<nav class="bg-gradient-to-r from-blue-600 to-blue-500 text-white py-4">
    <div class="container mx-auto flex justify-between items-center">
        <a href="<?php echo e(route('home')); ?>" class="text-xl font-bold">Blue Star Memory</a>
        <div class="space-x-4">
            <a href="<?php echo e(route('home')); ?>" class="hover:text-gray-300">Home</a>
            <a  class="hover:text-gray-300">About</a>
            <a class="hover:text-gray-300">Pricing</a>
            <a class="hover:text-gray-300">Contact</a>
            <?php if(auth()->guard()->check()): ?>
                <a  class="hover:text-gray-300">Dashboard</a>
                <form  method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="hover:text-gray-300">Logout</button>
                </form>
            <?php else: ?>
                <a class="hover:text-gray-300">Login</a>
                <a   class="hover:text-gray-300">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav><?php /**PATH D:\Projects Backends\blue-star-final\resources\views/components/navbar.blade.php ENDPATH**/ ?>